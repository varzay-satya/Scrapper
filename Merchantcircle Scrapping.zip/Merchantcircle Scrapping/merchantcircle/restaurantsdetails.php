<?php
require 'simplehtmldom_1_5/simple_html_dom.php';

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "merchantcircle";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 



for ($i=0; $i < 10; $i++) { 
        if($i == 0){
$url = 'https://www.merchantcircle.com/il-chicago/food-and-dining';
$html = file_get_html($url);
        $htmldata=$html->find('section.org');
        $j = 0;
        foreach($html->find('section.hTop div.hInfo') as $article) {
              $item['restaurant_link']     = $article->find('a', 0)->href;
              $item['company_id']          = $htmldata[$j]->attr['id'];
              /* $item['restaurant_name']     = $article->find('h2', 0)->plaintext;*/

              $sql = "INSERT INTO merchantciricle_items (company_id,company_link,referring_page) VALUES ('".$item['company_id']."','".$item['restaurant_link']."', '".$url."')";
              if ($conn->query($sql) === TRUE) {
                    echo "</br>";
                    echo "Referring Page- ".$url;
                    echo "</br>";
                    echo "Company link - ".$item['restaurant_link'];
                    echo "</br>";
                    echo "Company ID- ".$item['company_id'];
                    echo "</br>";
              } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
              }

              $j++;
        }
      }else{

  $value = $i*15;
  $referringurl = $url.'?start='.$value.'#hubResults';
  $html = file_get_html($referringurl);

  $htmldata=$html->find('section.org');
            $j = 0;
            foreach($html->find('section.hTop div.hInfo') as $article) {
                  $item['restaurant_link']     = $article->find('a', 0)->href;
                  $item['company_id']          = $htmldata[$j]->attr['id'];
                  /* $item['restaurant_name']     = $article->find('h2', 0)->plaintext;*/

                  $sql = "INSERT INTO merchantciricle_items (company_id,company_link,referring_page) VALUES ('".$item['company_id']."','".$item['restaurant_link']."', '".$referringurl."')";
                  if ($conn->query($sql) === TRUE) {
                        echo "</br>";
                        echo "Referring Page- ".$referringurl;
                        echo "</br>";
                        echo "Company link - ".$item['restaurant_link'];
                        echo "</br>";
                        echo "Company ID- ".$item['company_id'];
                        echo "</br>";
                  } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                  }

                  $j++;
            }
      }
}

$conn->close();
?>