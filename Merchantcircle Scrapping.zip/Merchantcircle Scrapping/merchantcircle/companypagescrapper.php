<?php
require 'simplehtmldom_1_5/simple_html_dom.php';
$datetime  = date('Y-m-d H:i:s');
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "merchantcircle";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sqlse = "SELECT id,company_link FROM merchantciricle_items";
$results = $conn->query($sqlse);

if ($results->num_rows > 0) {
    while($row = $results->fetch_assoc()) {
      $merchantcircle_item_id = $row["id"];
      $company_link = $row["company_link"];

      $html = file_get_html($company_link);
       foreach($html->find('div.info') as $article) {
              $item['phone']     = $article->find('div.phone span', 0)->plaintext; 
              $item['address']   = $article->find('div.directions', 0)->plaintext;
              $addrsexplode = explode('-',$item['address']);
              $address = $addrsexplode[0];
              $item['website']   = $article->find('a.url ', 0)->href;

               $sql = "INSERT INTO merchantcircle_details (merchantcircle_item_id,website,phone,address,created_at) VALUES ('".$merchantcircle_item_id."','".$item['website']."', '".$item['phone']."', '".$address."', '".$datetime."')";
              if ($conn->query($sql) === TRUE) {
                    echo "</br>";
                    echo "Merchantcircle Id- ".$merchantcircle_item_id;
                    echo "</br>";
                    echo "Website- ".$item['website'];
                    echo "</br>";
                    echo "Phone - ".$item['phone'];
                    echo "</br>";
                    echo "Address- ".$address;
                    echo "</br>";
              } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
              }   
            }
    }
} else {
    echo "0 results";
}

$conn->close();
?>