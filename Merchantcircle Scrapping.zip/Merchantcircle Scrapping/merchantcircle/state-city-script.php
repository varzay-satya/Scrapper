<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "merchantcircle";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sqlse = "SELECT state_code FROM merchantcircle_states";
$results = $conn->query($sqlse);

if ($results->num_rows > 0) {
    while($row = $results->fetch_assoc()) {
        $statecode = $row["state_code"];
 $shellexecurl = "curl --request GET \
  --url 'https://www.merchantcircle.com/ajax/call/getCitiesForState?state=".$statecode."' \
  --header 'cache-control: no-cache' \
  --header 'postman-token: e779f58c-3fa4-e2b6-67eb-e462fabe86aa'";
         $cities = shell_exec($shellexecurl);
         $trimcities = trim($cities, '[]');
         $city = str_replace('"','',$trimcities);
         $expcity = explode(',',$city);

         foreach ($expcity as $city) {
                    $sql = "INSERT INTO merchantcircle_cities (state_code, city_name) VALUES ('".$statecode."','".$city."')";
                    if ($conn->query($sql) === TRUE) {
                    echo "</br>";
                    echo "Success";
                    echo "</br>";
                    
                    } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                    }
         }
       
    }
} else {
    echo "0 results";
}
